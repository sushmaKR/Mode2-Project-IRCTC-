package com.pack.IrctcUser.Dto;

import java.util.ArrayList;
import java.util.List;

public class PassengerDto {
	List<PassengerDetails> passenger = new ArrayList<PassengerDetails>();
	private int bookingId;
	private String userId;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public List<PassengerDetails> getPassenger() {
		return passenger;
	}

	public void setPassenger(List<PassengerDetails> passenger) {
		this.passenger = passenger;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	
}
