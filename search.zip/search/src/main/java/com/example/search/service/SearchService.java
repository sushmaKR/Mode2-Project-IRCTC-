package com.example.search.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.search.dao.SearchDao;
import com.example.search.dto.SearchDto;
import com.example.search.dto.SearchDto1;
import com.example.search.dto.SeatDto;
import com.example.search.model.Train;

@Service
public class SearchService {
	List<Train> train = new ArrayList<Train>();
	SearchDto trainDetails = new SearchDto();
	SearchDto1 trainDetails1 = new SearchDto1();
	@Autowired
	private SearchDao searchDao;

	public void addTrainDetails(Train train) {
		searchDao.save(train);
	}

	public SearchDto getTrainByTrainNumber(String trainNumber) {
		train = searchDao.findByTrainNumber(trainNumber);
		trainDetails.setTrainName(train.get(0).getTrainName());
		trainDetails.setDate(train.get(0).getTrainId().getDate());
		trainDetails.setFromPlace(train.get(0).getFromPlace());
		trainDetails.setToPlace(train.get(0).getToPlace());
		trainDetails.setDepartureTime(train.get(0).getDepartureTime());
		trainDetails.setArrivalTime(train.get(0).getArrivalTime());
		trainDetails.setNumberOfSeatsAvailable(train.get(0).getNumberOfSeatsAvailable());
		trainDetails.setSeatFare(train.get(0).getSeatFare());
		return trainDetails;
	}

	public SearchDto1 getTrainByFromPlaceAndToPlaceAndDate(String fromPlace, String toPlace, LocalDate date) {
		train = searchDao.findByFromPlaceAndToPlaceAndDate(fromPlace, toPlace, date);
		trainDetails1.setTrainNumber(train.get(0).getTrainId().getTrainNumber());
		trainDetails1.setTrainName(train.get(0).getTrainName());
		trainDetails1.setDepartureTime(train.get(0).getDepartureTime());
		trainDetails1.setArrivalTime(train.get(0).getArrivalTime());
		trainDetails1.setNumberOfSeatsAvailable(train.get(0).getNumberOfSeatsAvailable());
		trainDetails1.setSeatFare(train.get(0).getSeatFare());
		return trainDetails1;

	}

	public void updateSeat(String trainNumber, SeatDto seatDto) {
		train = searchDao.findByTrainNumber(trainNumber);
		train.get(0).setNumberOfSeatsAvailable(seatDto.getNumberOfSeatsAvailable());
		searchDao.save(train.get(0));
	}
}