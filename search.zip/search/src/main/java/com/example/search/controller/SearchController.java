package com.example.search.controller;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.search.dto.SearchDto;
import com.example.search.dto.SearchDto1;
import com.example.search.dto.SeatDto;
import com.example.search.model.Train;
import com.example.search.service.SearchService;

@RestController
public class SearchController {
	@Autowired
	SearchService searchService;

	@PostMapping(value = "/add/train")
	public void addTrainDetails(@RequestBody Train train) {
		searchService.addTrainDetails(train);
	}
	
	@GetMapping(value="/train/{trainNumber}" )
	public SearchDto getTrainByTrainNumber(@PathVariable(value = "trainNumber") String trainNumber){
	return	searchService.getTrainByTrainNumber(trainNumber);
	}
	
	@GetMapping(value="/train/details/{fromPlace}/{toPlace}/{date}" )
	public SearchDto1 getTrainByFromPlaceAndToPlaceAndDate(@PathVariable(value = "fromPlace") String fromPlace,@PathVariable(value = "toPlace") String toPlace,@PathVariable(value = "date")  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date){
	return	searchService.getTrainByFromPlaceAndToPlaceAndDate(fromPlace, toPlace, date);
	}
	
	@PostMapping(value="/train/updateseat/{trainNumber}")
	public void updateSeats(@PathVariable(value = "trainNumber") String trainNumber,@RequestBody SeatDto seatDto){
		 searchService.updateSeat(trainNumber,seatDto);
	}
}
