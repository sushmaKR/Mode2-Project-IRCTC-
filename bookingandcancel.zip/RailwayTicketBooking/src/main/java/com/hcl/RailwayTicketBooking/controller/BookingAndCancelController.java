package com.hcl.RailwayTicketBooking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.RailwayTicketBooking.DTO.BookingDto;
import com.hcl.RailwayTicketBooking.DTO.PassengerDto;
import com.hcl.RailwayTicketBooking.service.BookingAndCancelService;

@RestController
public class BookingAndCancelController {
	@Autowired
	BookingAndCancelService bookingService;

	@PostMapping(value = "/addBookingDetails")
	public int addBooking(@RequestBody BookingDto requestdata) {

		return bookingService.addBooking(requestdata);
	}

	@DeleteMapping(value = "/user/cancelTicket/{PNRNumber}")

	public void deletePassenger(@PathVariable(value = "PNRNumber") String pnrNumber) {

		bookingService.deletePassengerTicket(pnrNumber);

	}

	@PostMapping(value = "/addPassenger")
	public List<String> addPassenger(@RequestBody PassengerDto passengerDto) {
		return bookingService.addPassengerDetails(passengerDto);
	}

}
