package com.hcl.RailwayTicketBooking.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hcl.RailwayTicketBooking.model.Passenger;

@Repository
public interface PassengerDao extends CrudRepository<Passenger, String> {
	@Query(value = "SELECT MAX(seat_number) FROM passenger", nativeQuery = true)
	Integer findbymaxseatNumber();

	@Query(value = "select p.pnrnumber from passenger p where p.booking_id=?1", nativeQuery = true)

	List<String> findBybookingId(int bookingId);

}
