package com.hcl.RailwayTicketBooking.DTO;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class BookingDto {
	private String trainNumber;
	private LocalDate date;
	private String userId;
	
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getTrainNumber() {
		return trainNumber;
	}
	public void setTrainNumber(String trainNumber) {
		this.trainNumber = trainNumber;
	}
	
	
}
